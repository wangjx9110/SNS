<?php
  header('Content-type: text/css; charset=utf-8');
  sleep(5);
?>

#red { color: red }
