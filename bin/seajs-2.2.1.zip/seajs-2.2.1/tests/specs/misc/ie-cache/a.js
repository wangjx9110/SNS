define(function(require, exports) {
  exports.name = 'a'
});
