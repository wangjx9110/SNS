define("main.js",
    [
      "1.js",
      "2.js",
      "3.js",
      "4.js",
      "5.js",
      "6.js",
      "7.js"

    ], function() {
    });
