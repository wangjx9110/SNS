define(function(require, exports) {

  exports.foo = function () {
    return 'bar'
  }

});
