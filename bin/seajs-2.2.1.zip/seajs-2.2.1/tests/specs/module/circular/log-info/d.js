define(function(require, exports) {
  exports.name = 'd'
  exports.e = require('./e')
});

